package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void testAddContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertEquals(1, service.getAllContacts().size());
    }

    @Test
    void testAddContactDuplicateIdFail() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("123456", "Jane", "Smith", "0987654321", "456 Elm St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    void testDeleteContactSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.deleteContact("123456");
        assertEquals(0, service.getAllContacts().size());
    }

    @Test
    void testUpdateContactFirstNameSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateContactFirstName("123456", "Jane");
        Contact updatedContact = service.getContact("123456");
        assertEquals("Jane", updatedContact.getFirstName());
    }

    @Test
    void testUpdateContactLastNameSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateContactLastName("123456", "Smith");
        Contact updatedContact = service.getContact("123456");
        assertEquals("Smith", updatedContact.getLastName());
    }

    @Test
    void testUpdateContactPhoneSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateContactPhone("123456", "0987654321");
        Contact updatedContact = service.getContact("123456");
        assertEquals("0987654321", updatedContact.getPhone());
    }

    @Test
    void testUpdateContactAddressSuccess() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateContactAddress("123456", "456 Elm St");
        Contact updatedContact = service.getContact("123456");
        assertEquals("456 Elm St", updatedContact.getAddress());
    }
}
