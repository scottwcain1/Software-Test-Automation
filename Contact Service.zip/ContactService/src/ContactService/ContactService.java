package ContactService;

import java.util.ArrayList;  // Add this import statement
import java.util.HashMap;
import java.util.List;        // Add this import statement
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    public void updateContactFirstName(String contactID, String firstName) {
        Contact contact = contacts.get(contactID);
        if (contact != null && firstName != null && firstName.length() <= 10) {
            contact.setFirstName(firstName);
        }
    }

    public void updateContactLastName(String contactID, String lastName) {
        Contact contact = contacts.get(contactID);
        if (contact != null && lastName != null && lastName.length() <= 10) {
            contact.setLastName(lastName);
        }
    }

    public void updateContactPhone(String contactID, String phone) {
        Contact contact = contacts.get(contactID);
        if (contact != null && phone != null && phone.matches("\\d{10}")) {
            contact.setPhone(phone);
        }
    }

    public void updateContactAddress(String contactID, String address) {
        Contact contact = contacts.get(contactID);
        if (contact != null && address != null && address.length() <= 30) {
            contact.setAddress(address);
        }
    }

    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }

    public List<Contact> getAllContacts() {
        return new ArrayList<>(contacts.values());
    }
}
